
public class EstimacionCorLineal {

    private double dblSumX;
    public double dblSumY;
    public double dblSumXY;
    public double dblSumXX;
    public double dblSumYY;
    public double dblAvgX;
    public double dblAvgY;
    public double dblB1;
    public double dblRXY;
    public double dblB0;
    public double dblR;
    public double dblXk;
    public double dblYk;
    public int intN;
    //public String[] result;
    
    /**
     * Default constructor
     */
    public EstimacionCorLineal() {

    }

    public String[] Estimacion(String[] datalist, int n) {
        sumX(datalist, n);
        sumY(datalist, n);
        sumXX(datalist, n);
        sumXY(datalist, n);
        sumYY(datalist, n);
        getAvgX(n);
        getAvgY(n);
        getB1();
        getB0();
        getRXY();
        getYk();
        getR();

        String result[] = new String[12];

        result[0]= String.valueOf(dblSumX);
        result[1]= String.valueOf(dblSumY);
        result[2]= String.valueOf(dblSumXX);
        result[3]= String.valueOf(dblSumXY);
        result[4]= String.valueOf(dblSumYY);
        result[5]= String.valueOf(dblAvgX);
        result[6]= String.valueOf(dblAvgY);
        result[7]= String.valueOf(dblB1);
        result[8]= String.valueOf(dblB0);
        result[9]= String.valueOf(dblRXY);
        result[10]= String.valueOf(dblYk);
        result[11]= String.valueOf(dblR);

        return result;
    }

    /**
     * @param datalist
     */
    public void sumX(String[] datalist, int n) {
        dblSumX=0;
        for (int i=0; i<n; i=i+2){
            dblSumX=dblSumX+Double.parseDouble(datalist[i]);
        }
        System.out.println("SumX = " + dblSumX);
    }

    /**
     * @param datalist
     */
    public void sumY(String[] datalist, int n) {
        for (int i=1; i<n; i=i+2){
            dblSumY=dblSumY+Double.parseDouble(datalist[i]);
        }
        System.out.println("SumY = " + dblSumY);
    }

    /**
     * @param datalist
     */
    public void sumXX(String[] datalist, int n) {
        for (int i=0; i<n; i=i+2){
            dblSumXX= dblSumXX + (Double.parseDouble(datalist[i]) * Double.parseDouble(datalist[i]));
        }
        System.out.println("SumXX = " + dblSumXX);
    }

    /**
     * @param datalist
     */
    public void sumXY(String[] datalist, int n) {
        int j=-1;
        for (int i=0; i<n; i=i+2){
                j=j+2;
                dblSumXY= dblSumXY + (Double.parseDouble(datalist[i]) * Double.parseDouble(datalist[j]));
        }
        System.out.println("SumXY = " + dblSumXY);
    }

    /**
     * @param datalist
     */
    public void sumYY(String[] datalist, int n) {
        for (int i=1; i<n; i=i+2){
            dblSumYY= dblSumYY + (Double.parseDouble(datalist[i]) * Double.parseDouble(datalist[i]));
        }
        System.out.println("SumYY = " + dblSumYY);
    }

    /**
     * @param datalist
     */
    public void getAvgX(int n) {
        dblAvgX = dblSumX/(n-10);
        System.out.println("AvgX = " + dblAvgX);
    }

    /**
     * @param datalist
     */
    public void getAvgY(int n) {
        dblAvgY = dblSumY/(n-10);
        System.out.println("AvgY = " + dblAvgY);
    }

    public void getB1() {
        dblB1= (dblSumXY-(10*dblAvgX*dblAvgY))/(dblSumXX-(10*(dblAvgX*dblAvgX)));
        System.out.println("B1 = " + dblB1);
    }

    public void getRXY() {
        dblRXY= (10*dblSumXY-dblSumX*dblSumY)/(Math.sqrt((10*dblSumXX-(dblSumX*dblSumX))*(10*dblSumYY-(dblSumY*dblSumY))));
        System.out.println("Rxy = " + dblRXY);
    }

    public void getB0() {
      dblB0=dblAvgY-dblB1*dblAvgX;
      System.out.println("B0 = " + dblB0);
    }

    public void getYk() {
      dblYk = dblB0 + dblB1 * 386;
      System.out.println("Yk = " + dblYk);
    }

    public void getR() {
        dblR = dblRXY * dblRXY;
        System.out.println("R^2 = " + dblR);
    }

}