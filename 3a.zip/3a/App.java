
public class App {

    public App() {
        
    }

    /**
     * @param args
     * @return
     */
    public static void main(String[] args) {
        Logic myLogic = new Logic();
        myLogic.logic3a();
    }

}