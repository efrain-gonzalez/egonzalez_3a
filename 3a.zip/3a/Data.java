
public class Data {

    /**
     * Default constructor
     */
    public Data() {
    }

    /**
     * @param data 
     * @return
     */
    public String[] saveData(String data) {
        String[] arrData = data.split(",");
        return arrData;
    }

}